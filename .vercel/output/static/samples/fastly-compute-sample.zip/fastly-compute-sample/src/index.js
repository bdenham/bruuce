import { env } from "fastly:env";
import { pass, fetch } from "fastly:experimental";

addEventListener("fetch", (event) => event.respondWith(handleRequest(event)));

async function handleRequest(event) {
    let req = event.request;
    let url = new URL(req.url);

    // Define a list of protected URLs
    const protectedUrls = [
        "/camping-gear/outdoor-furniture-gear.html",
        "/camping-chair-foldable.html",
    ];

    // Check if the request URL path is in the protected list
    if (protectedUrls.includes(url.pathname)) {
        // Validate user authentication
        let validationResponse = await validateUser(req);

        if (validationResponse.ok) {
            // User is validated, continue processing normally
            return pass(req);
        } else {
            // Redirect to login page if validation fails
            return Response.redirect("https://www.example.com/customer/account/login", 302);
        }
    }

    // If the URL is not protected, process the request as normal
    return pass(req);
}

// Function to validate the user by making an external API call
async function validateUser(req) {
    const validationUrl = "https://www.example.com/graphql";

    try {
        let validationReq = new Request(validationUrl, {
            method: "POST",
            headers: {
                "Authorization": req.headers.get("Authorization") || "",
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ url: req.url }),
        });

        return await fetch(validationReq);
    } catch (error) {
        console.error("Validation request failed:", error);
        return Response.redirect("https://www.example.com/customer/account/login", 302);
      }
}